# Models
Learning models and data processing libraries.

Run `setup.py` to download the newest MindReader data set.